$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Creating a Job Vacancy",
  "description": "I want to use this template for my feature file",
  "id": "creating-a-job-vacancy",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity1"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "To create a job vacancy for Devops Engineer",
  "description": "",
  "id": "creating-a-job-vacancy;to-create-a-job-vacancy-for-devops-engineer",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@JobVacancy"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Login into Orange HRM",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "navigate to the recruitment page",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "the user click on Vacancies menu item to navigate to vacancies page",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "clicks on the Add button to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "fill the necessary details and clicks Save",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "verify the vacancy was created",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "quit the browser",
  "keyword": "And "
});
formatter.match({
  "location": "CreateJobVacancy.login_into_Orange_HRM()"
});
formatter.result({
  "duration": 11050171500,
  "status": "passed"
});
formatter.match({
  "location": "CreateJobVacancy.navigate_to_the_recruitment_page()"
});
formatter.result({
  "duration": 782802100,
  "status": "passed"
});
formatter.match({
  "location": "CreateJobVacancy.the_user_click_on_Vacancies_menu_item_to_navigate_to_vacancies_page()"
});
formatter.result({
  "duration": 513495900,
  "status": "passed"
});
formatter.match({
  "location": "CreateJobVacancy.clicks_on_the_Add_button_to_the_Add_Job_Vacancy_form()"
});
formatter.result({
  "duration": 381298100,
  "status": "passed"
});
formatter.match({
  "location": "CreateJobVacancy.fill_the_necessary_details_and_clicks_Save()"
});
formatter.result({
  "duration": 1080655000,
  "status": "passed"
});
formatter.match({
  "location": "CreateJobVacancy.verify_the_vacancy_was_created()"
});
formatter.result({
  "duration": 2070856200,
  "status": "passed"
});
formatter.match({
  "location": "CreateJobVacancy.quit_the_browser()"
});
formatter.result({
  "duration": 1877348200,
  "status": "passed"
});
formatter.uri("Activity2.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Add candidate for recruitment",
  "description": "I want to use this template for my feature file",
  "id": "add-candidate-for-recruitment",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity2"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "Add information about a candidate for recruitment",
  "description": "",
  "id": "add-candidate-for-recruitment;add-information-about-a-candidate-for-recruitment",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@AddCandidate"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "User logs into Orange HRM",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "Navigate to the Recruitment page",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "clicks on the Add button to add candidateinformation",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "fill in the details of the candidate",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "upload a resume",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "click Save",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "Navigate back to Recruitments page to confirm candidate entry",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "user logs off from browser",
  "keyword": "And "
});
formatter.match({
  "location": "AddingCandidate.user_logs_into_Orange_HRM()"
});
formatter.result({
  "duration": 7489100600,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.navigate_to_the_Recruitment_page()"
});
formatter.result({
  "duration": 830881300,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.clicks_on_the_Add_button_to_add_candidateinformation()"
});
formatter.result({
  "duration": 1278069200,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.fill_in_the_details_of_the_candidate()"
});
formatter.result({
  "duration": 141060300,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.upload_a_resume()"
});
formatter.result({
  "duration": 41905400,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.click_Save()"
});
formatter.result({
  "duration": 580313800,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.navigate_back_to_Recruitments_page_to_confirm_candidate_entry()"
});
formatter.result({
  "duration": 1556831800,
  "status": "passed"
});
formatter.match({
  "location": "AddingCandidate.user_logs_off_from_browser()"
});
formatter.result({
  "duration": 1668130400,
  "status": "passed"
});
formatter.uri("Activity3.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Adding Mutiple Employees",
  "description": "I want to use this template for my feature file",
  "id": "adding-mutiple-employees",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    }
  ]
});
formatter.scenarioOutline({
  "line": 28,
  "name": "Add multiple employees using the Examples table",
  "description": "",
  "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 27,
      "name": "@AddMultipleEmployees"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "User is on OrangeHRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user logs in with credentials provided",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "find the PIM option in the menu and click it",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "click the Add button to add a new Employee",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "make sure the create login details checkbox is checked",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "user adds multiple employees using \"\u003cFirstName\u003e\" and \"\u003cLastName\u003e\" and \"\u003cUserName\u003e\" and \"\u003cPassword\u003e\" and click Save",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "verify that the employees have been created",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "close the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 38,
  "name": "",
  "description": "",
  "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table;",
  "rows": [
    {
      "cells": [
        "FirstName",
        "LastName",
        "UserName",
        "Password"
      ],
      "line": 39,
      "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table;;1"
    },
    {
      "cells": [
        "aaPriya",
        "Jay",
        "aaPriya",
        "1231!@#aaa"
      ],
      "line": 40,
      "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table;;2"
    },
    {
      "cells": [
        "abPriya",
        "Jaya",
        "abPriya",
        "112!@sss3a"
      ],
      "line": 41,
      "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 40,
  "name": "Add multiple employees using the Examples table",
  "description": "",
  "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    },
    {
      "line": 27,
      "name": "@AddMultipleEmployees"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "User is on OrangeHRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user logs in with credentials provided",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "find the PIM option in the menu and click it",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "click the Add button to add a new Employee",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "make sure the create login details checkbox is checked",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "user adds multiple employees using \"aaPriya\" and \"Jay\" and \"aaPriya\" and \"1231!@#aaa\" and click Save",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "verify that the employees have been created",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "close the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "AddMultipleEmployees.user_is_on_OrangeHRM_page()"
});
formatter.result({
  "duration": 6020795400,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.user_logs_in_with_credentials_provided()"
});
formatter.result({
  "duration": 1341683700,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.find_the_PIM_option_in_the_menu_and_click_it()"
});
formatter.result({
  "duration": 664128300,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.click_the_Add_button_to_add_a_new_Employee()"
});
formatter.result({
  "duration": 461687800,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.make_sure_the_Create_Login_Details_checkbox_is_checked()"
});
formatter.result({
  "duration": 300348500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "aaPriya",
      "offset": 36
    },
    {
      "val": "Jay",
      "offset": 50
    },
    {
      "val": "aaPriya",
      "offset": 60
    },
    {
      "val": "1231!@#aaa",
      "offset": 74
    }
  ],
  "location": "AddMultipleEmployees.user_adds_multiple_employees_using_and_and_and_and_click_Save(String,String,String,String)"
});
formatter.result({
  "duration": 1239711500,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.verify_that_the_employees_have_been_created()"
});
formatter.result({
  "duration": 1665583700,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.close_the_Browser()"
});
formatter.result({
  "duration": 1608758400,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "Add multiple employees using the Examples table",
  "description": "",
  "id": "adding-mutiple-employees;add-multiple-employees-using-the-examples-table;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    },
    {
      "line": 27,
      "name": "@AddMultipleEmployees"
    }
  ]
});
formatter.step({
  "line": 29,
  "name": "User is on OrangeHRM page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user logs in with credentials provided",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "find the PIM option in the menu and click it",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "click the Add button to add a new Employee",
  "keyword": "Then "
});
formatter.step({
  "line": 33,
  "name": "make sure the create login details checkbox is checked",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "user adds multiple employees using \"abPriya\" and \"Jaya\" and \"abPriya\" and \"112!@sss3a\" and click Save",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "verify that the employees have been created",
  "keyword": "Then "
});
formatter.step({
  "line": 36,
  "name": "close the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "AddMultipleEmployees.user_is_on_OrangeHRM_page()"
});
formatter.result({
  "duration": 5989684000,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.user_logs_in_with_credentials_provided()"
});
formatter.result({
  "duration": 1300229300,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.find_the_PIM_option_in_the_menu_and_click_it()"
});
formatter.result({
  "duration": 784603900,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.click_the_Add_button_to_add_a_new_Employee()"
});
formatter.result({
  "duration": 430033100,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.make_sure_the_Create_Login_Details_checkbox_is_checked()"
});
formatter.result({
  "duration": 276248100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "abPriya",
      "offset": 36
    },
    {
      "val": "Jaya",
      "offset": 50
    },
    {
      "val": "abPriya",
      "offset": 61
    },
    {
      "val": "112!@sss3a",
      "offset": 75
    }
  ],
  "location": "AddMultipleEmployees.user_adds_multiple_employees_using_and_and_and_and_click_Save(String,String,String,String)"
});
formatter.result({
  "duration": 1173335200,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.verify_that_the_employees_have_been_created()"
});
formatter.result({
  "duration": 1377072200,
  "status": "passed"
});
formatter.match({
  "location": "AddMultipleEmployees.close_the_Browser()"
});
formatter.result({
  "duration": 1749035100,
  "status": "passed"
});
formatter.uri("Activity4.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Creating multiple Vacancies",
  "description": "I want to use this template for my feature file",
  "id": "creating-multiple-vacancies",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.scenarioOutline({
  "line": 27,
  "name": "Creating multiple vacancies using data from examples",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@JobVacancies"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login with the credentials into Orange HRM",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "navigate to the recruitment page for adding vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "user  clicks on Vacancies menu item to navigate to vacancies page",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "user clicks on the Add button to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "fill Details \"\u003cVacancyName\u003e\" and \"\u003cHiringManager\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "click the Save button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "verify all the vacanies are successfully created",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Logout from the browser",
  "keyword": "And "
});
formatter.examples({
  "line": 37,
  "name": "",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples;",
  "rows": [
    {
      "cells": [
        "VacancyName",
        "HiringManager"
      ],
      "line": 38,
      "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples;;1"
    },
    {
      "cells": [
        "aaJuniorQAEngineer",
        "Priya J"
      ],
      "line": 39,
      "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples;;2"
    },
    {
      "cells": [
        "aaSeniorQAEngineer",
        "Priya J"
      ],
      "line": 40,
      "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 39,
  "name": "Creating multiple vacancies using data from examples",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@JobVacancies"
    },
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login with the credentials into Orange HRM",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "navigate to the recruitment page for adding vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "user  clicks on Vacancies menu item to navigate to vacancies page",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "user clicks on the Add button to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "fill Details \"aaJuniorQAEngineer\" and \"Priya J\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "click the Save button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "verify all the vacanies are successfully created",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Logout from the browser",
  "keyword": "And "
});
formatter.match({
  "location": "CreateMultipleVacancies.login_with_the_credentials_into_Orange_HRM()"
});
formatter.result({
  "duration": 7225028200,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.navigate_to_the_recruitment_page_for_adding_vacancies()"
});
formatter.result({
  "duration": 805286900,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.user_clicks_on_Vacancies_menu_item_to_navigate_to_vacancies_page()"
});
formatter.result({
  "duration": 542403400,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.user_clicks_on_the_Add_button_to_the_Add_Job_Vacancy_form()"
});
formatter.result({
  "duration": 479388400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "aaJuniorQAEngineer",
      "offset": 14
    },
    {
      "val": "Priya J",
      "offset": 39
    }
  ],
  "location": "CreateMultipleVacancies.fill_Details_and(String,String)"
});
formatter.result({
  "duration": 416037500,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.click_the_Save_button()"
});
formatter.result({
  "duration": 432584000,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.verify_all_the_vacanies_are_successfully_created()"
});
formatter.result({
  "duration": 462057800,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.logout_from_the_browser()"
});
formatter.result({
  "duration": 2377730800,
  "status": "passed"
});
formatter.scenario({
  "line": 40,
  "name": "Creating multiple vacancies using data from examples",
  "description": "",
  "id": "creating-multiple-vacancies;creating-multiple-vacancies-using-data-from-examples;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@JobVacancies"
    },
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login with the credentials into Orange HRM",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "navigate to the recruitment page for adding vacancies",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "user  clicks on Vacancies menu item to navigate to vacancies page",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "user clicks on the Add button to the Add Job Vacancy form",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "fill Details \"aaSeniorQAEngineer\" and \"Priya J\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "click the Save button",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "verify all the vacanies are successfully created",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "Logout from the browser",
  "keyword": "And "
});
formatter.match({
  "location": "CreateMultipleVacancies.login_with_the_credentials_into_Orange_HRM()"
});
formatter.result({
  "duration": 7415931600,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.navigate_to_the_recruitment_page_for_adding_vacancies()"
});
formatter.result({
  "duration": 841731500,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.user_clicks_on_Vacancies_menu_item_to_navigate_to_vacancies_page()"
});
formatter.result({
  "duration": 561698100,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.user_clicks_on_the_Add_button_to_the_Add_Job_Vacancy_form()"
});
formatter.result({
  "duration": 645917600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "aaSeniorQAEngineer",
      "offset": 14
    },
    {
      "val": "Priya J",
      "offset": 39
    }
  ],
  "location": "CreateMultipleVacancies.fill_Details_and(String,String)"
});
formatter.result({
  "duration": 415741400,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.click_the_Save_button()"
});
formatter.result({
  "duration": 566464800,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.verify_all_the_vacanies_are_successfully_created()"
});
formatter.result({
  "duration": 701028300,
  "status": "passed"
});
formatter.match({
  "location": "CreateMultipleVacancies.logout_from_the_browser()"
});
formatter.result({
  "duration": 1784157000,
  "status": "passed"
});
});