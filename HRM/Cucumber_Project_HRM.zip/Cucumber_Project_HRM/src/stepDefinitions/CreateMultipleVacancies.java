package stepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
//import cucumber.api.junit.Cucumber;
//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateMultipleVacancies {
	
	WebDriver driver;
    WebDriverWait wait;
		
	@Given("^Login with the credentials into Orange HRM$")
	public void login_with_the_credentials_into_Orange_HRM() throws Throwable {
		driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co/orangehrm");	 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");				
		driver.findElement(By.id("btnLogin")).click();	
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Given("^navigate to the recruitment page for adding vacancies$")
	public void navigate_to_the_recruitment_page_for_adding_vacancies() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^user  clicks on Vacancies menu item to navigate to vacancies page$")
	public void user_clicks_on_Vacancies_menu_item_to_navigate_to_vacancies_page() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^user clicks on the Add button to the Add Job Vacancy form$")
	public void user_clicks_on_the_Add_button_to_the_Add_Job_Vacancy_form() throws Throwable {
		driver.findElement(By.xpath("//input[@id='btnAdd']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}


	@When("^fill Details \"([^\"]*)\" and \"([^\"]*)\"$")
	public void fill_Details_and(String VacancyName, String HiringManager) throws Throwable {
		
		WebElement JobTitle = driver.findElement(By.id("addJobVacancy_jobTitle"));
		Select select = new Select(JobTitle);
		select.selectByValue("3");
		
			
		driver.findElement(By.id("addJobVacancy_name")).sendKeys(VacancyName);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys(HiringManager);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^click the Save button$")
	public void click_the_Save_button() throws Throwable {
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^verify all the vacanies are successfully created$")
	public void verify_all_the_vacanies_are_successfully_created() throws Throwable {
	   
		driver.findElement(By.xpath("//input[@id='btnBack']")).click();
				
		WebElement verifyJobVacancy = driver.findElement(By.xpath("//a[contains(text(),VacancyName)]"));
		verifyJobVacancy.isSelected();
								
		System.out.println("Creation of Job Vacancy has been completed successfully: " +verifyJobVacancy);
					
	}

	@Then("^Logout from the browser$")
	public void logout_from_the_browser() throws Throwable {
		driver.close();
	}	
}
