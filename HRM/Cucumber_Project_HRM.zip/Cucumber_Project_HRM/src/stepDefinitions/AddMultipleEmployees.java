package stepDefinitions;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddMultipleEmployees {
	WebDriver driver;
    WebDriverWait wait;
	
	@Given("^User is on OrangeHRM page$")
	public void user_is_on_OrangeHRM_page() throws Throwable {
		driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co/orangehrm");	    
	}

	@When("^user logs in with credentials provided$")
	public void user_logs_in_with_credentials_provided() throws Throwable {
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");				
		driver.findElement(By.id("btnLogin")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	}

	@Then("^find the PIM option in the menu and click it$")
	public void find_the_PIM_option_in_the_menu_and_click_it() throws Throwable {
       
		driver.findElement(By.xpath("//*[@id=\"menu_pim_viewPimModule\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}

	@Then("^click the Add button to add a new Employee$")
	public void click_the_Add_button_to_add_a_new_Employee() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_pim_addEmployee\"]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^make sure the create login details checkbox is checked$")
	public void make_sure_the_Create_Login_Details_checkbox_is_checked() throws Throwable {
		
		driver.findElement(By.xpath("//input[@id='chkLogin']")).click(); 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	
	@When("^user adds multiple employees using \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" using Examples and click Save$")
	public void user_adds_multiple_employees_using_and_and_using_Examples_and_click_Save(String FirstName, String LastName, String UserName) throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_pim_addEmployee\"]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("firstName")).sendKeys(FirstName);
		driver.findElement(By.id("lastName")).sendKeys(LastName);
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='chkLogin']")).click(); 
		//driver.findElement(By.id("user_name")).sendKeys(UserName);
		driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys(UserName);
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//input[@id='btnSave']")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@When("^user adds multiple employees using \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and click Save$")
	public void user_adds_multiple_employees_using_and_and_and_and_click_Save(String FirstName, String LastName, String UserName, String Password) throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_pim_addEmployee\"]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("firstName")).sendKeys(FirstName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		driver.findElement(By.id("lastName")).sendKeys(LastName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		driver.findElement(By.xpath("//input[@id='chkLogin']")).click(); 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
		driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys(UserName);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
		driver.findElement(By.xpath("//input[@id='user_password']")).sendKeys(Password);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
        driver.findElement(By.xpath("//input[@id='btnSave']")).click();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
	}
	
	@Then("^verify that the employees have been created$")
	public void verify_that_the_employees_have_been_created() throws Throwable {
      		
		driver.findElement(By.linkText("Employee List")).click();		
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	      
	    driver.findElement(By.id("searchBtn")).click();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    	      
	     WebElement CreateEmployee = driver.findElement(By.xpath("//a[contains(text(),FirstName)]"));
		 CreateEmployee.isSelected();
									
		 System.out.println("Add Employee has been completed successfully: " +CreateEmployee);
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									
	}

	@Then("^close the Browser$")
	public void close_the_Browser() throws Throwable {
		driver.close();
	}	
}
