package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateJobVacancy {
	WebDriver driver;
    WebDriverWait wait;
    
	@Given("^Login into Orange HRM$")
	public void login_into_Orange_HRM() throws Throwable {
		driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co/orangehrm");	 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");				
		driver.findElement(By.id("btnLogin")).click();	
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Given("^navigate to the recruitment page$")
	public void navigate_to_the_recruitment_page() throws Throwable {
		
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^the user click on Vacancies menu item to navigate to vacancies page$")
	public void the_user_click_on_Vacancies_menu_item_to_navigate_to_vacancies_page() throws Throwable {
		
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^clicks on the Add button to the Add Job Vacancy form$")
	public void clicks_on_the_Add_button_to_the_Add_Job_Vacancy_form() throws Throwable {
	    
		driver.findElement(By.xpath("//input[@id='btnAdd']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^fill the necessary details and clicks Save$")
	public void fill_the_necessary_details_and_clicks_Save() throws Throwable {
	    
		WebElement JobTitle = driver.findElement(By.id("addJobVacancy_jobTitle"));
		Select select = new Select(JobTitle);
		select.selectByValue("3");
		
		driver.findElement(By.id("addJobVacancy_name")).sendKeys("aaTest Specialist Automation");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("Priya J");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("addJobVacancy_noOfPositions")).sendKeys("5");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("addJobVacancy_description")).sendKeys("BDD Cucumber and Selenium ");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
						
	}
	
	@Then("^verify the vacancy was created$")
	
	public void verify_the_vacancy_was_created() throws Throwable {
				
		driver.findElement(By.xpath("//input[@id='btnBack']")).click();
							
		WebElement Vacancy = driver.findElement(By.id("vacancySearch_jobVacancy"));
		Vacancy.sendKeys("aaTest Specialist Automation");		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		
		WebElement HiringManager = driver.findElement(By.id("vacancySearch_hiringManager"));		
		HiringManager.sendKeys("Priya J");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
		driver.findElement(By.xpath("//input[@id='btnSrch']")).click();
		
		WebElement verifyJobVacancy = driver.findElement(By.linkText("aaTest Specialist Automation"));
		verifyJobVacancy.isSelected();
			
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		String Job = verifyJobVacancy.getAttribute("href");
		
		System.out.println("Creation of Job Vacancy has been completed successfully: " +verifyJobVacancy);
		System.out.println("Creation of Job Vacancy has been completed successfully: " +Job);
		
	}

	@Then("^quit the browser$")
	public void quit_the_browser() throws Throwable {
		driver.close();
	}
	
	
}
