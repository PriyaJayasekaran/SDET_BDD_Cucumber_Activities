package stepDefinitions;


import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddingCandidate {

	WebDriver driver;
    WebDriverWait wait;
    
	@Given("^User logs into Orange HRM$")
	public void user_logs_into_Orange_HRM() throws Throwable {
		driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co/orangehrm");	 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");				
		driver.findElement(By.id("btnLogin")).click();	
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Given("^Navigate to the Recruitment page$")
	public void navigate_to_the_Recruitment_page() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^clicks on the Add button to add candidateinformation$")
	public void clicks_on_the_Add_button_to_add_candidateinformation() throws Throwable {
		
		driver.findElement(By.id("menu_recruitment_viewCandidates")).click();
		driver.findElement(By.xpath("//input[@id='btnAdd']")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^fill in the details of the candidate$")
	public void fill_in_the_details_of_the_candidate() throws Throwable {
	    
		driver.findElement(By.id("addCandidate_firstName")).sendKeys("Priya");
		driver.findElement(By.id("addCandidate_lastName")).sendKeys("Jayasekaran");
		driver.findElement(By.id("addCandidate_email")).sendKeys("123@gmail.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}

	@When("^upload a resume$")
	public void upload_a_resume() throws Throwable {
		
		WebElement uploadResume = driver.findElement(By.id("addCandidate_resume"));
   	 driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
   	 
   	uploadResume.sendKeys("C:\\Users\\PriyaJayasekaran\\Downloads\\Testing_Resume.doc");
    driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	
     
	}

	@Then("^click Save$")
	public void click_Save() throws Throwable {
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^Navigate back to Recruitments page to confirm candidate entry$")
	public void navigate_back_to_Recruitments_page_to_confirm_candidate_entry() throws Throwable {
		driver.findElement(By.xpath("//input[@id='btnBack']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//WebElement AddCandidate = driver.findElement(By.partialLinkText("Priya Jayasekaran"));
		//AddCandidate.click();
			
		String CandidateEntry =	driver.findElement(By.linkText("Priya Jayasekaran")).getText();
        Assert.assertEquals("Priya Jayasekaran", CandidateEntry);
    	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	
		System.out.println("Adding Candidate completed successfully: " +CandidateEntry);
	}

	@Then("^user logs off from browser$")
	public void user_logs_off_from_browser() throws Throwable {
	    driver.close();
	}

	
	
}
