package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
//import org.junit.Assert;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class JobPostingwithExamples {
	WebDriver driver;
    WebDriverWait wait;
    
	@Given("^Open broswer with Alchemy Jobsite$")
	public void open_broswer_with_Alchemy_Jobsite() throws Throwable {
		driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
	}

	@Then("^user clicks on post job$")
	public void user_clicks_on_post_job() throws Throwable {
		driver.get("https://alchemy.hguy.co/jobs/"); 
		
		driver.findElement(By.xpath("//a[text()='Post a Job']")).click();
		//driver.navigate().to("https://alchemy.hguy.co/jobs/post-a-job/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@When("^user provides Email \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_provides_Email_and_and(String email, String jobtitle, String jobdescription) throws Throwable {
	    
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("create_account_email"))));
		driver.findElement(By.id("create_account_email")).sendKeys(email);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("job_title")).sendKeys(jobtitle);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.switchTo().frame("job_description_ifr");

	    driver.findElement(By.xpath("//body[@id='tinymce']")).sendKeys(jobdescription);

	    driver.switchTo().defaultContent();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^fills the \"([^\"]*)\" and \"([^\"]*)\"$")
	public void fills_the_and(String appUrl, String companyname) throws Throwable {
		
		driver.findElement(By.id("application")).sendKeys(appUrl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("company_name")).sendKeys(companyname);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	@When("^clicks on Submit button$")
	public void clicks_on_Submit_button() throws Throwable {
		driver.findElement(By.name("submit_job")).click();

    	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("job_preview_submit_button"))));
		 
		 driver.findElement(By.id("job_preview_submit_button")).click();
	}
	
	@Then("^listing should be available on Jobs page$")
	public void listing_should_be_available_on_Jobs_page() throws Throwable {
		driver.findElement(By.xpath("//a[text()='Job Dashboard']")).click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    String jobpost = driver.findElement(By.xpath("//table[@class='job-manager-jobs']//tbody//td/small")).getText();
	    
	    if(jobpost.contains("Pending")) {
	    	System.out.println("Confirm Job listing is displayed on the  Jobs page is: " + jobpost);
	    }
	    
	    else {
	    	
			   System.out.println("Confirm Job listing is not displayed on the  Jobs page is: " + jobpost);

		   }	    		
	}

	@Then("^exit from broswer$")
	public void exit_from_broswer() throws Throwable {
		driver.close();
	}	
}
