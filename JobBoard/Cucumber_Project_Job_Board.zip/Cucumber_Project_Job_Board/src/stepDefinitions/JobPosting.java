package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
//import org.junit.Assert;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class JobPosting {
	WebDriver driver;
    WebDriverWait wait;
	
	@Given("^user is on the Alchemy Jobsite$")
	public void user_is_on_the_Alchemy_Jobsite() throws Throwable {
		driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
	}

	@Then("^click on Post a job$")
	public void click_on_Post_a_job() throws Throwable {
		driver.get("https://alchemy.hguy.co/jobs/"); 
		driver.navigate().to("https://alchemy.hguy.co/jobs/post-a-job/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Then("^Enter the Email \"([^\"]*)\" and JobTitle \"([^\"]*)\"$")
	public void enter_the_Email_and_JobTitle(String email, String jobtitle) throws Throwable {
		
   wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("create_account_email"))));
   
		driver.findElement(By.id("create_account_email")).sendKeys(email);
		driver.findElement(By.id("job_title")).sendKeys(jobtitle);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Then("^Enter the JobDescription \"([^\"]*)\"$")
	public void enter_the_JobDescription(String desc) throws Throwable {
		
		driver.switchTo().frame("job_description_ifr");
	    driver.findElement(By.xpath("//body[@id='tinymce']")).sendKeys(desc);

	    driver.switchTo().defaultContent();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Then("^Enter the ApplicationUrl \"([^\"]*)\" and CompanyName \"([^\"]*)\"$")
	public void enter_the_ApplicationUrl_and_CompanyName(String AppUrl, String companyname) throws Throwable {
		
		driver.findElement(By.id("application")).sendKeys(AppUrl);
		driver.findElement(By.id("company_name")).sendKeys(companyname);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Then("^Click submit$")
	public void click_submit() throws Throwable {
		driver.findElement(By.name("submit_job")).click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("job_preview_submit_button"))));

		 driver.findElement(By.id("job_preview_submit_button")).click();
		 
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	
	@Then("^user should be able to see the listing on Jobs page$")
	public void user_should_be_able_to_see_the_listing_on_Jobs_page() throws Throwable {
		
		driver.findElement(By.xpath("//a[text()='Job Dashboard']")).click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
	    String jobpost = driver.findElement(By.xpath("//table[@class='job-manager-jobs']//tbody//td/small")).getText();
	    
	    if(jobpost.contains("Pending")) {
	    	System.out.println("Confirm Job listing is displayed on the  Jobs page is: " + jobpost);
	    }
	    
	    else {
	    	
			   System.out.println("Confirm Job listing is not displayed on the  Jobs page is: " + jobpost);
		   }	   				
	}

	@Then("^user logs out from the Alchemy Jobsite$")
	public void user_logs_out_from_the_Alchemy_Jobsite() throws Throwable {
	    driver.close();
	}	
}
