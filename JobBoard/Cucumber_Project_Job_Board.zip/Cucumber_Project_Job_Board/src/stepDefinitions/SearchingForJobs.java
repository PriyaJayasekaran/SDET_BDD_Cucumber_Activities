package stepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;

public class SearchingForJobs {
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User logs in and navigate to Jobs page$")
    public void OpenBrowser() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open the Browser
        driver.get("https://alchemy.hguy.co/jobs/"); 
        driver.findElement(By.xpath("//html/body/div/header/div/div/div/div/div[3]/div/nav/div/ul/li[1]/a")).click();
        //driver.findElement(By.linkText("https://alchemy.hguy.co/jobs/jobs/")).click();  
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    
    @And("^find the keywords and does search for jobs by entering values$")
    public void KeywordSearch() throws Throwable {
    	//Clicking on Search Keyword
    	driver.findElement(By.id("search_keywords")).sendKeys("testing");
    	//driver.findElement(By.id("search_location")).sendKeys("Bangalore");
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	//driver.findElement(By.xpath("//button[@value='Search Jobs']")).click();
    	  	   	    	
    }
    
    
    @When("^filter job type to show only Full Time jobs$")
    public void JobType() throws Throwable {
          //Clicking on User button 
    	
    	driver.findElement(By.id("job_type_freelance")).click();

	    driver.findElement(By.id("job_type_internship")).click();

	    driver.findElement(By.id("job_type_part-time")).click();

	    driver.findElement(By.id("job_type_temporary")).click();
	    
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    
    }
    
     
    @Then("^find the title of job using XPath and print it to the console and click on Apply$")
    public void JobTitle() throws Throwable {
    	
    	
    	List<WebElement> Job = driver.findElements(By.xpath("//li[contains(@class,'job_listing status')]//div/h3"));

	    int iApplyJob=0;

		for (int i = 0; i < Job.size(); i++) {

	    	String JobList = Job.get(i).getText();

	    	if(JobList.equalsIgnoreCase("Associate SW Test Engineer")) {

	    		iApplyJob=i;

	    	}

			System.out.println("Available JobLists are:"+JobList);

		}

		Job.get(iApplyJob).click();
    	     
    }
    
  
    
    @And("^close off the browser$")
    public void closeoffBrowser() {
        //Close browser
        driver.close();
    }
	
}
