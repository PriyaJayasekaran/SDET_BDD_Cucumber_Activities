package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Assert;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class NewUserCreation {
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User logs in and selects the User Menu$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open the Browser
        driver.get("https://alchemy.hguy.co/jobs/wp-login.php");       
        //Enter user name
        driver.findElement(By.id("user_login")).sendKeys("root");        
        //Enter pass word
        driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");        
        //Click Login        
        driver.findElement(By.id("wp-submit")).click();       
    }
    
    
    @When("^user locates the Add New button$")
    public void locate() throws Throwable {
          //Clicking on User button 	
    	driver.findElement(By.className("wp-menu-name")).click();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	      
    }
    
    @And("^clicks on the Add New User button$")
    public void AddNewUser() throws Throwable {
    	//Clicking on Add New User
    	driver.findElement(By.id("menu-users")).click();   	
    	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[11]/ul/li[3]/a")).click();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
    }
    
    
    @And("^fill the necessary details$")
    public void FillInfo() throws Throwable {
    	//Enter user login
    	driver.findElement(By.id("user_login")).sendKeys("aaaPriya");
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        //Enter email
        driver.findElement(By.id("email")).sendKeys("priya123@gmail.com");
        
        //Enter first name
        driver.findElement(By.id("first_name")).sendKeys("Priya");
        
        //Enter last name
        driver.findElement(By.id("last_name")).sendKeys("Jayasekaran");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        
        //Clicking on new user submission
        driver.findElement(By.id("createusersub")).click();
        
    }
    
    @Then("^verify user was created$")
    public void VerifyUser() throws Throwable {
    	
    	driver.findElement(By.id("menu-users")).click();
    	driver.findElement(By.xpath("//html/body/div[1]/div[1]/div[2]/ul/li[11]/ul/li[2]/a")).click();
    	
  	    // User search
    	driver.findElement(By.id("user-search-input")).sendKeys("aaPriya");
    	driver.findElement(By.id("search-submit")).click();
    	
    	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    	
    	String UserName = driver.findElement(By.xpath("//tbody[@id='the-list']//td/strong/a")).getText();

		if(UserName.contains("aaaPriya")) {

			System.out.println("User creation have been verified successfully");

		}

		else {

			System.out.println("User creation have not been verified successfully");

		}
                            
    }
    
    @And("^close the browser$")
    public void closeBrowser() {
        //Close browser
        driver.close();
    }
	
	
	
}
