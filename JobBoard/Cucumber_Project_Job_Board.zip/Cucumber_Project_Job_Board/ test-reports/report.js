$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "New User creation",
  "description": "I want to use this template for my feature file",
  "id": "new-user-creation",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity1"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "Visit the site�s backend and create a new user",
  "description": "",
  "id": "new-user-creation;visit-the-site�s-backend-and-create-a-new-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@NewUserCreation"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "User logs in and selects the User Menu",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user locates the Add New button",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "clicks on the Add New User button",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "fill the necessary details",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "verify user was created",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "close the browser",
  "keyword": "And "
});
formatter.match({
  "location": "NewUserCreation.loginPage()"
});
formatter.result({
  "duration": 13568258100,
  "status": "passed"
});
formatter.match({
  "location": "NewUserCreation.locate()"
});
formatter.result({
  "duration": 1415583600,
  "status": "passed"
});
formatter.match({
  "location": "NewUserCreation.AddNewUser()"
});
formatter.result({
  "duration": 2774363600,
  "status": "passed"
});
formatter.match({
  "location": "NewUserCreation.FillInfo()"
});
formatter.result({
  "duration": 1255114000,
  "status": "passed"
});
formatter.match({
  "location": "NewUserCreation.VerifyUser()"
});
formatter.result({
  "duration": 3786457900,
  "status": "passed"
});
formatter.match({
  "location": "NewUserCreation.closeBrowser()"
});
formatter.result({
  "duration": 2224755400,
  "status": "passed"
});
formatter.uri("Activity2.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Search jobs",
  "description": "I want to use this template for my feature file",
  "id": "search-jobs",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity2"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "Searching for jobs using XPath",
  "description": "",
  "id": "search-jobs;searching-for-jobs-using-xpath",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@SearchingForJobs"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "User logs in and navigate to Jobs page",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "find the keywords and does search for jobs by entering values",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "filter job type to show only Full Time jobs",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "find the title of job using XPath and print it to the console and click on Apply",
  "keyword": "Then "
});
formatter.step({
  "line": 31,
  "name": "close off the browser",
  "keyword": "And "
});
formatter.match({
  "location": "SearchingForJobs.OpenBrowser()"
});
formatter.result({
  "duration": 7103806000,
  "status": "passed"
});
formatter.match({
  "location": "SearchingForJobs.KeywordSearch()"
});
formatter.result({
  "duration": 79666800,
  "status": "passed"
});
formatter.match({
  "location": "SearchingForJobs.JobType()"
});
formatter.result({
  "duration": 1033465500,
  "status": "passed"
});
formatter.match({
  "location": "SearchingForJobs.JobTitle()"
});
formatter.result({
  "duration": 1083253500,
  "status": "passed"
});
formatter.match({
  "location": "SearchingForJobs.closeoffBrowser()"
});
formatter.result({
  "duration": 1643681100,
  "status": "passed"
});
formatter.uri("Activity3.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Posting a Job",
  "description": "I want to use this template for my feature file",
  "id": "posting-a-job",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "Post a job using details from file",
  "description": "",
  "id": "posting-a-job;post-a-job-using-details-from-file",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@JobPosting"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "user is on the Alchemy Jobsite",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "click on Post a job",
  "keyword": "Then "
});
formatter.step({
  "line": 29,
  "name": "Enter the Email \"jaya3@gmail.com\" and JobTitle \"DevOps Eng\"",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Enter the JobDescription \"Alchemy sol\"",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Enter the ApplicationUrl \"https://alchemy.hguy.co/jobs/post-a-job/\" and CompanyName \"IBM\"",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Click submit",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "user should be able to see the listing on Jobs page",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "user logs out from the Alchemy Jobsite",
  "keyword": "And "
});
formatter.match({
  "location": "JobPosting.user_is_on_the_Alchemy_Jobsite()"
});
formatter.result({
  "duration": 6052287200,
  "status": "passed"
});
formatter.match({
  "location": "JobPosting.click_on_Post_a_job()"
});
formatter.result({
  "duration": 2149127900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "jaya3@gmail.com",
      "offset": 17
    },
    {
      "val": "DevOps Eng",
      "offset": 48
    }
  ],
  "location": "JobPosting.enter_the_Email_and_JobTitle(String,String)"
});
formatter.result({
  "duration": 265762500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Alchemy sol",
      "offset": 26
    }
  ],
  "location": "JobPosting.enter_the_JobDescription(String)"
});
formatter.result({
  "duration": 30210627100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://alchemy.hguy.co/jobs/post-a-job/",
      "offset": 26
    },
    {
      "val": "IBM",
      "offset": 85
    }
  ],
  "location": "JobPosting.enter_the_ApplicationUrl_and_CompanyName(String,String)"
});
formatter.result({
  "duration": 175520300,
  "status": "passed"
});
formatter.match({
  "location": "JobPosting.click_submit()"
});
formatter.result({
  "duration": 1608944100,
  "status": "passed"
});
formatter.match({
  "location": "JobPosting.user_should_be_able_to_see_the_listing_on_Jobs_page()"
});
formatter.result({
  "duration": 592216500,
  "status": "passed"
});
formatter.match({
  "location": "JobPosting.user_logs_out_from_the_Alchemy_Jobsite()"
});
formatter.result({
  "duration": 2066828800,
  "status": "passed"
});
formatter.uri("Activity4.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Title of your feature",
  "description": "I want to use this template for my feature file",
  "id": "title-of-your-feature",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.scenarioOutline({
  "line": 27,
  "name": "Post a job using details from file with examples",
  "description": "",
  "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 26,
      "name": "@JobPostingwithExamples"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Open broswer with Alchemy Jobsite",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user clicks on post job",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "user provides Email \"\u003cEmail\u003e\" and \"\u003cJobTitle\u003e\" and \"\u003cJobDescription\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "fills the \"\u003cApplicationUrl\u003e\" and \"\u003cCompanyName\u003e\"",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "clicks on Submit button",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "listing should be available on Jobs page",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "exit from broswer",
  "keyword": "And "
});
formatter.examples({
  "line": 36,
  "name": "",
  "description": "",
  "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples;",
  "rows": [
    {
      "cells": [
        "Email",
        "JobTitle",
        "JobDescription",
        "ApplicationUrl",
        "CompanyName"
      ],
      "line": 37,
      "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples;;1"
    },
    {
      "cells": [
        "jp123@gmail.com",
        "Junior QA Eng",
        "Alchemy soln",
        "https://alchemy.hguy.co/jobs/post-a-job/",
        "IBM"
      ],
      "line": 38,
      "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples;;2"
    },
    {
      "cells": [
        "va123@gmail.com",
        "Senior QA Eng",
        "Alchemy soln",
        "https://alchemy.hguy.co/jobs/post-a-job/",
        "IBM"
      ],
      "line": 39,
      "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 38,
  "name": "Post a job using details from file with examples",
  "description": "",
  "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity4"
    },
    {
      "line": 26,
      "name": "@JobPostingwithExamples"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Open broswer with Alchemy Jobsite",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user clicks on post job",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "user provides Email \"jp123@gmail.com\" and \"Junior QA Eng\" and \"Alchemy soln\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "fills the \"https://alchemy.hguy.co/jobs/post-a-job/\" and \"IBM\"",
  "matchedColumns": [
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "clicks on Submit button",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "listing should be available on Jobs page",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "exit from broswer",
  "keyword": "And "
});
formatter.match({
  "location": "JobPostingwithExamples.open_broswer_with_Alchemy_Jobsite()"
});
formatter.result({
  "duration": 4859839700,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.user_clicks_on_post_job()"
});
formatter.result({
  "duration": 2162806600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "jp123@gmail.com",
      "offset": 21
    },
    {
      "val": "Junior QA Eng",
      "offset": 43
    },
    {
      "val": "Alchemy soln",
      "offset": 63
    }
  ],
  "location": "JobPostingwithExamples.user_provides_Email_and_and(String,String,String)"
});
formatter.result({
  "duration": 10362761500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://alchemy.hguy.co/jobs/post-a-job/",
      "offset": 11
    },
    {
      "val": "IBM",
      "offset": 58
    }
  ],
  "location": "JobPostingwithExamples.fills_the_and(String,String)"
});
formatter.result({
  "duration": 174300600,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.clicks_on_Submit_button()"
});
formatter.result({
  "duration": 1623853700,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.listing_should_be_available_on_Jobs_page()"
});
formatter.result({
  "duration": 641353900,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.exit_from_broswer()"
});
formatter.result({
  "duration": 1631417000,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "Post a job using details from file with examples",
  "description": "",
  "id": "title-of-your-feature;post-a-job-using-details-from-file-with-examples;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity4"
    },
    {
      "line": 26,
      "name": "@JobPostingwithExamples"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Open broswer with Alchemy Jobsite",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user clicks on post job",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "user provides Email \"va123@gmail.com\" and \"Senior QA Eng\" and \"Alchemy soln\"",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "fills the \"https://alchemy.hguy.co/jobs/post-a-job/\" and \"IBM\"",
  "matchedColumns": [
    3,
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "clicks on Submit button",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "listing should be available on Jobs page",
  "keyword": "Then "
});
formatter.step({
  "line": 34,
  "name": "exit from broswer",
  "keyword": "And "
});
formatter.match({
  "location": "JobPostingwithExamples.open_broswer_with_Alchemy_Jobsite()"
});
formatter.result({
  "duration": 5679394300,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.user_clicks_on_post_job()"
});
formatter.result({
  "duration": 2283792200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "va123@gmail.com",
      "offset": 21
    },
    {
      "val": "Senior QA Eng",
      "offset": 43
    },
    {
      "val": "Alchemy soln",
      "offset": 63
    }
  ],
  "location": "JobPostingwithExamples.user_provides_Email_and_and(String,String,String)"
});
formatter.result({
  "duration": 10493634400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://alchemy.hguy.co/jobs/post-a-job/",
      "offset": 11
    },
    {
      "val": "IBM",
      "offset": 58
    }
  ],
  "location": "JobPostingwithExamples.fills_the_and(String,String)"
});
formatter.result({
  "duration": 152063400,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.clicks_on_Submit_button()"
});
formatter.result({
  "duration": 1611697000,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.listing_should_be_available_on_Jobs_page()"
});
formatter.result({
  "duration": 518394400,
  "status": "passed"
});
formatter.match({
  "location": "JobPostingwithExamples.exit_from_broswer()"
});
formatter.result({
  "duration": 1753918700,
  "status": "passed"
});
});