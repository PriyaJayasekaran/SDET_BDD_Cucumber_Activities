$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Counting Dashlets",
  "description": "I want to use this template for my feature file",
  "id": "counting-dashlets",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity1"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "Open the Homepage and count the number of the dashlets on the page",
  "description": "",
  "id": "counting-dashlets;open-the-homepage-and-count-the-number-of-the-dashlets-on-the-page",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@DashletCount"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Login to AlchemyCRM",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "count the number of Dashlets on Hompepage",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "print the number of dashlets into console",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "Logout from Alchemy CRM",
  "keyword": "And "
});
formatter.match({
  "location": "CountingDashlets.login_to_AlchemyCRM()"
});
formatter.result({
  "duration": 11003386000,
  "status": "passed"
});
formatter.match({
  "location": "CountingDashlets.count_the_number_of_Dashlets_on_Hompepage()"
});
formatter.result({
  "duration": 776333500,
  "status": "passed"
});
formatter.match({
  "location": "CountingDashlets.print_the_number_of_dashlets_into_console()"
});
formatter.result({
  "duration": 344581000,
  "status": "passed"
});
formatter.match({
  "location": "CountingDashlets.logout_from_Alchemy_CRM()"
});
formatter.result({
  "duration": 1786717000,
  "status": "passed"
});
formatter.uri("Activity2.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Create leads using parameterization",
  "description": "I want to use this template for my feature file",
  "id": "create-leads-using-parameterization",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity2"
    }
  ]
});
formatter.scenario({
  "line": 26,
  "name": "Open the Leads page and add multiple lead accounts using values passed from file",
  "description": "",
  "id": "create-leads-using-parameterization;open-the-leads-page-and-add-multiple-lead-accounts-using-values-passed-from-file",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@LeadsCreation"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "User is on Alchemy CRM",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "Navigate to Sales then Leads and then Create Lead",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "Fill the necessary details by giving FirstName \"Priya\" and LastName \"Jayasekaran\" and Description \"CreateLead\"",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "User clicks on Save to finish",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Navigate to View Leads page to see the results",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "User logs off Alchemy CRM",
  "keyword": "And "
});
formatter.match({
  "location": "CreatingLeads.user_is_on_Alchemy_CRM()"
});
formatter.result({
  "duration": 8990227100,
  "status": "passed"
});
formatter.match({
  "location": "CreatingLeads.navigate_to_Sales_then_Leads_and_then_Create_Lead()"
});
formatter.result({
  "duration": 6372062700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Priya",
      "offset": 48
    },
    {
      "val": "Jayasekaran",
      "offset": 69
    },
    {
      "val": "CreateLead",
      "offset": 99
    }
  ],
  "location": "CreatingLeads.fill_the_necessary_details_by_giving_FirstName_and_LastName_and_Description(String,String,String)"
});
formatter.result({
  "duration": 3455017400,
  "status": "passed"
});
formatter.match({
  "location": "CreatingLeads.user_clicks_on_Save_to_finish()"
});
formatter.result({
  "duration": 4944098500,
  "status": "passed"
});
formatter.match({
  "location": "CreatingLeads.navigate_to_View_Leads_page_to_see_the_results()"
});
formatter.result({
  "duration": 5971033800,
  "status": "passed"
});
formatter.match({
  "location": "CreatingLeads.user_logs_off_Alchemy_CRM()"
});
formatter.result({
  "duration": 2325715800,
  "status": "passed"
});
formatter.uri("Activity3.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Schedule a meeting and invite members",
  "description": "I want to use this template for my feature file",
  "id": "schedule-a-meeting-and-invite-members",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    }
  ]
});
formatter.scenarioOutline({
  "line": 26,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 25,
      "name": "@ScheduleMeeting"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login to Suite CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Enter the Subject \"\u003cSubject\u003e\" and Search for members \"\u003cName\u003e\" and add them to the meeting",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"\u003cSubject\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "to close the CRM browser",
  "keyword": "Then "
});
formatter.examples({
  "line": 35,
  "name": "",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;",
  "rows": [
    {
      "cells": [
        "Subject",
        "Name"
      ],
      "line": 36,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;1"
    },
    {
      "cells": [
        "TeamMeetingforQA",
        "QAUsers"
      ],
      "line": 37,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;2"
    },
    {
      "cells": [
        "TeamMeetingforDEV",
        "DEVUsers"
      ],
      "line": 38,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;3"
    },
    {
      "cells": [
        "TeamMeetingforBA",
        "BAUsers"
      ],
      "line": 39,
      "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;4"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 37,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    },
    {
      "line": 25,
      "name": "@ScheduleMeeting"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login to Suite CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Enter the Subject \"TeamMeetingforQA\" and Search for members \"QAUsers\" and add them to the meeting",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"TeamMeetingforQA\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "to close the CRM browser",
  "keyword": "Then "
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.login_to_Suite_CRM_with_credentials()"
});
formatter.result({
  "duration": 10276181200,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.navigate_to_Activities_then_Meetings_and_then_Schedule_a_Meeting()"
});
formatter.result({
  "duration": 6277827700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "TeamMeetingforQA",
      "offset": 19
    },
    {
      "val": "QAUsers",
      "offset": 61
    }
  ],
  "location": "ScheduleMeetingwithExamples.enter_the_Subject_and_Search_for_members_and_add_them_to_the_meeting(String,String)"
});
formatter.result({
  "duration": 9704349100,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.click_Save_Meeting_to_finish()"
});
formatter.result({
  "duration": 4336834700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "TeamMeetingforQA",
      "offset": 72
    }
  ],
  "location": "ScheduleMeetingwithExamples.navigate_to_View_Meetings_page_and_confirm_creation_of_the_meeting_for(String)"
});
formatter.result({
  "duration": 3724588200,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.close_the_CRMbrowser()"
});
formatter.result({
  "duration": 2235269200,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    },
    {
      "line": 25,
      "name": "@ScheduleMeeting"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login to Suite CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Enter the Subject \"TeamMeetingforDEV\" and Search for members \"DEVUsers\" and add them to the meeting",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"TeamMeetingforDEV\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "to close the CRM browser",
  "keyword": "Then "
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.login_to_Suite_CRM_with_credentials()"
});
formatter.result({
  "duration": 8466493900,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.navigate_to_Activities_then_Meetings_and_then_Schedule_a_Meeting()"
});
formatter.result({
  "duration": 6262916800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "TeamMeetingforDEV",
      "offset": 19
    },
    {
      "val": "DEVUsers",
      "offset": 62
    }
  ],
  "location": "ScheduleMeetingwithExamples.enter_the_Subject_and_Search_for_members_and_add_them_to_the_meeting(String,String)"
});
formatter.result({
  "duration": 9704323900,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.click_Save_Meeting_to_finish()"
});
formatter.result({
  "duration": 4287174600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "TeamMeetingforDEV",
      "offset": 72
    }
  ],
  "location": "ScheduleMeetingwithExamples.navigate_to_View_Meetings_page_and_confirm_creation_of_the_meeting_for(String)"
});
formatter.result({
  "duration": 3664740400,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.close_the_CRMbrowser()"
});
formatter.result({
  "duration": 2388076300,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "To schedule a meeting and include at least 3 invitees",
  "description": "",
  "id": "schedule-a-meeting-and-invite-members;to-schedule-a-meeting-and-include-at-least-3-invitees;;4",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 21,
      "name": "@activity3"
    },
    {
      "line": 25,
      "name": "@ScheduleMeeting"
    }
  ]
});
formatter.step({
  "line": 28,
  "name": "Login to Suite CRM with credentials",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "Navigate to Activities then Meetings and then Schedule a Meeting",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Enter the Subject \"TeamMeetingforBA\" and Search for members \"BAUsers\" and add them to the meeting",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Click Save Meeting to finish",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Navigate to View Meetings page and confirm creation of the meeting for \"TeamMeetingforBA\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 33,
  "name": "to close the CRM browser",
  "keyword": "Then "
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.login_to_Suite_CRM_with_credentials()"
});
formatter.result({
  "duration": 8774879100,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.navigate_to_Activities_then_Meetings_and_then_Schedule_a_Meeting()"
});
formatter.result({
  "duration": 6313998300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "TeamMeetingforBA",
      "offset": 19
    },
    {
      "val": "BAUsers",
      "offset": 61
    }
  ],
  "location": "ScheduleMeetingwithExamples.enter_the_Subject_and_Search_for_members_and_add_them_to_the_meeting(String,String)"
});
formatter.result({
  "duration": 9661238000,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.click_Save_Meeting_to_finish()"
});
formatter.result({
  "duration": 4281145800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "TeamMeetingforBA",
      "offset": 72
    }
  ],
  "location": "ScheduleMeetingwithExamples.navigate_to_View_Meetings_page_and_confirm_creation_of_the_meeting_for(String)"
});
formatter.result({
  "duration": 3733971700,
  "status": "passed"
});
formatter.match({
  "location": "ScheduleMeetingwithExamples.close_the_CRMbrowser()"
});
formatter.result({
  "duration": 1683380500,
  "status": "passed"
});
formatter.uri("Activity4.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 22,
  "name": "Creating a Product",
  "description": "I want to use this template for my feature file",
  "id": "creating-a-product",
  "keyword": "Feature",
  "tags": [
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.scenarioOutline({
  "line": 26,
  "name": "To use an external Excel to add products",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 25,
      "name": "@ProductCreation"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Open the Alchemy CRM site and login",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user navigates to All then Products and then Create Product",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "enter the details of the product \"\u003cProductName\u003e\" and \"\u003cPrice\u003e\" and \"\u003cDescription\u003e\" using data from Examples table",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "click Save To Create Product",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "go to the View Products page to see all products listed",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "exit the Alchemy CRM browser",
  "keyword": "And "
});
formatter.examples({
  "line": 34,
  "name": "",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products;",
  "rows": [
    {
      "cells": [
        "ProductName",
        "Price",
        "Description"
      ],
      "line": 35,
      "id": "creating-a-product;to-use-an-external-excel-to-add-products;;1"
    },
    {
      "cells": [
        "XYCRMProduct",
        "5",
        "Adding Product1"
      ],
      "line": 36,
      "id": "creating-a-product;to-use-an-external-excel-to-add-products;;2"
    },
    {
      "cells": [
        "JPCRMProduct",
        "7",
        "Adding Product2"
      ],
      "line": 37,
      "id": "creating-a-product;to-use-an-external-excel-to-add-products;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 36,
  "name": "To use an external Excel to add products",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 25,
      "name": "@ProductCreation"
    },
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Open the Alchemy CRM site and login",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user navigates to All then Products and then Create Product",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "enter the details of the product \"XYCRMProduct\" and \"5\" and \"Adding Product1\" using data from Examples table",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "click Save To Create Product",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "go to the View Products page to see all products listed",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "exit the Alchemy CRM browser",
  "keyword": "And "
});
formatter.match({
  "location": "CreatingProductwithExamples.open_the_Alchemy_CRM_site_and_login()"
});
formatter.result({
  "duration": 9069984500,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.user_navigates_to_All_then_Products_and_then_Create_Product()"
});
formatter.result({
  "duration": 7806507200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "XYCRMProduct",
      "offset": 34
    },
    {
      "val": "5",
      "offset": 53
    },
    {
      "val": "Adding Product1",
      "offset": 61
    }
  ],
  "location": "CreatingProductwithExamples.enter_the_details_of_the_product_and_and_using_Examples_table(String,String,String)"
});
formatter.result({
  "duration": 181356800,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.click_Save_To_Create_Product()"
});
formatter.result({
  "duration": 6546799300,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.go_to_the_View_Products_page_to_see_all_products_listed()"
});
formatter.result({
  "duration": 1317943700,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.exit_the_Alchemy_CRM_browser()"
});
formatter.result({
  "duration": 1657843300,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "To use an external Excel to add products",
  "description": "",
  "id": "creating-a-product;to-use-an-external-excel-to-add-products;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 25,
      "name": "@ProductCreation"
    },
    {
      "line": 21,
      "name": "@activity4"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "Open the Alchemy CRM site and login",
  "keyword": "Given "
});
formatter.step({
  "line": 28,
  "name": "user navigates to All then Products and then Create Product",
  "keyword": "When "
});
formatter.step({
  "line": 29,
  "name": "enter the details of the product \"JPCRMProduct\" and \"7\" and \"Adding Product2\" using data from Examples table",
  "matchedColumns": [
    0,
    1,
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "click Save To Create Product",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "go to the View Products page to see all products listed",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "exit the Alchemy CRM browser",
  "keyword": "And "
});
formatter.match({
  "location": "CreatingProductwithExamples.open_the_Alchemy_CRM_site_and_login()"
});
formatter.result({
  "duration": 8998061900,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.user_navigates_to_All_then_Products_and_then_Create_Product()"
});
formatter.result({
  "duration": 8389954700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "JPCRMProduct",
      "offset": 34
    },
    {
      "val": "7",
      "offset": 53
    },
    {
      "val": "Adding Product2",
      "offset": 61
    }
  ],
  "location": "CreatingProductwithExamples.enter_the_details_of_the_product_and_and_using_Examples_table(String,String,String)"
});
formatter.result({
  "duration": 224396000,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.click_Save_To_Create_Product()"
});
formatter.result({
  "duration": 6212805100,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.go_to_the_View_Products_page_to_see_all_products_listed()"
});
formatter.result({
  "duration": 1002213300,
  "status": "passed"
});
formatter.match({
  "location": "CreatingProductwithExamples.exit_the_Alchemy_CRM_browser()"
});
formatter.result({
  "duration": 2018995500,
  "status": "passed"
});
});