package stepDefinitions;
import java.awt.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
//import cucumber.api.junit.Cucumber;
//import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreatingLeads {
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User is on Alchemy CRM$")
    public void user_is_on_Alchemy_CRM() throws Throwable {
    	driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		
		driver.get("http://alchemy.hguy.co/crm");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    @Given("^Navigate to Sales then Leads and then Create Lead$")
    public void navigate_to_Sales_then_Leads_and_then_Create_Lead() throws Throwable {
    	
    	driver.findElement(By.xpath("//a[text()='Sales']")).click();

		JavascriptExecutor js=(JavascriptExecutor)driver;

		js.executeScript("arguments[0].click()",	
				
		driver.findElement(By.xpath("(//a[text()='Leads'])[3]")));
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//div[text()='Create Lead']")).click();
		
		Thread.sleep(3000);
    }

    
    @When("^Fill the necessary details by giving FirstName \"([^\"]*)\" and LastName \"([^\"]*)\" and Description \"([^\"]*)\"$")
    public void fill_the_necessary_details_by_giving_FirstName_and_LastName_and_Description(String FirstName, String LastName, String Description) throws Throwable {
    	
    	Select salution=new Select(driver.findElement(By.id("salutation")));

		salution.selectByVisibleText("Ms.");

		driver.findElement(By.id("first_name")).sendKeys(FirstName);

		driver.findElement(By.id("last_name")).sendKeys(LastName);
		
		driver.findElement(By.id("description")).sendKeys(Description);

		Thread.sleep(3000);
    }
    
    @When("^User clicks on Save to finish$")
    public void user_clicks_on_Save_to_finish() throws Throwable {
    	
    	driver.findElement(By.id("SAVE")).click();
    	Thread.sleep(3000);   	   	
    }

    @Then("^Navigate to View Leads page to see the results$")
    public void navigate_to_View_Leads_page_to_see_the_results() throws Throwable {
   	
    	driver.findElement(By.xpath("//div[text()='View Leads']")).click();

		Thread.sleep(3000);

		driver.findElement(By.partialLinkText("Priya Jayasekaran")).click();
		String result = driver.findElement(By.partialLinkText("Priya Jayasekaran")).getText();
		
		System.out.println("Creation of Lead is successful:" +result);

		}
    

    @Then("^User logs off Alchemy CRM$")
    public void user_logs_off_Alchemy_CRM() throws Throwable {
        driver.close();
    }

}
