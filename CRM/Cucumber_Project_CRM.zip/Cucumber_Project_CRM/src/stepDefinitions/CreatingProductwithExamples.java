package stepDefinitions;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class CreatingProductwithExamples {
	
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open the Alchemy CRM site and login$")
    public void open_the_Alchemy_CRM_site_and_login() throws Throwable {
    	driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		
		driver.get("http://alchemy.hguy.co/crm");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @When("^user navigates to All then Products and then Create Product$")
    public void user_navigates_to_All_then_Products_and_then_Create_Product() throws Throwable {
       
        //driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
              
        //driver.findElement(By.className("actionmenulink")).click();
        
        driver.findElement(By.xpath("//a[text()='All']")).click();
       
        WebElement Element = driver.findElement(By.linkText("Products"));     
        
        Element.click();
        
        		
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//div[text()='Create Product']")).click();

		Thread.sleep(2000);
		
    }

    @When("^enter the details of the product \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" using data from Examples table$")
    public void enter_the_details_of_the_product_and_and_using_Examples_table(String ProductName, String Price, String Description) throws Throwable {
       
    	driver.findElement(By.id("name")).sendKeys(ProductName);
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
    	driver.findElement(By.id("price")).sendKeys(Price);
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
    	driver.findElement(By.id("description")).sendKeys(Description);
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
    }
    
    @And("^click Save To Create Product$")

	public void click_Save_To_Create_Product() throws Throwable {

	    driver.findElement(By.xpath("(//input[@id='SAVE'])[2]")).click();

	    Thread.sleep(5000);

	}
    	
    
    @Then("^go to the View Products page to see all products listed$")
    public void go_to_the_View_Products_page_to_see_all_products_listed() throws Throwable {
        driver.findElement(By.partialLinkText("View Products")).click();
        
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    @Then("^exit the Alchemy CRM browser$")
    public void exit_the_Alchemy_CRM_browser() throws Throwable {
        driver.close();
    }

}
