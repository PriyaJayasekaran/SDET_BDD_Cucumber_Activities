package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ScheduleMeetingwithExamples {
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Login to Suite CRM with credentials$")
    public void login_to_Suite_CRM_with_credentials() throws Throwable {
    	driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		
		driver.get("http://alchemy.hguy.co/crm");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
	@Given("^Navigate to Activities then Meetings and then Schedule a Meeting$")
	public void navigate_to_Activities_then_Meetings_and_then_Schedule_a_Meeting() throws Throwable {
		driver.findElement(By.xpath("//a[text()='Activities']")).click();

		JavascriptExecutor js=(JavascriptExecutor)driver;

		js.executeScript("arguments[0].click()",		

		driver.findElement(By.xpath("//a[text()='Meetings']")));

		Thread.sleep(3000);

		driver.findElement(By.xpath("//div[text()='Schedule Meeting']")).click();

		Thread.sleep(3000);
	}

	@Given("^Enter the Subject \"([^\"]*)\" and Search for members \"([^\"]*)\" and add them to the meeting$")
	public void enter_the_Subject_and_Search_for_members_and_add_them_to_the_meeting(String Subject, String Name) throws Throwable {
		driver.findElement(By.id("name")).sendKeys(Subject);
		//driver.findElement(By.id("assigned_user_name")).clear();

		Thread.sleep(3000);
		
		driver.findElement(By.id("search_first_name")).sendKeys(Name);

		//driver.findElement(By.id("assigned_user_name")).sendKeys(Name);
		

		Thread.sleep(3000);
		
		driver.findElement(By.id("invitees_search")).click();
				
		driver.findElement(By.xpath("//*[@id=\"invitees_add_1\"]")).click();
		Thread.sleep(3000);

		
	}

	@Given("^Click Save Meeting to finish$")
	public void click_Save_Meeting_to_finish() throws Throwable {
		driver.findElement(By.id("SAVE_HEADER")).click();

		Thread.sleep(3000);
	}

	@When("^Navigate to View Meetings page and confirm creation of the meeting for \"([^\"]*)\"$")
	public void navigate_to_View_Meetings_page_and_confirm_creation_of_the_meeting_for(String Meeting) throws Throwable {
		driver.findElement(By.xpath("//div[text()='View Meetings']")).click();

		Thread.sleep(3000);

		String confirm = driver.findElement(By.xpath("//table[@class='list view table-responsive']/tbody//td[@field='name']/b/a")).getText();

		if(confirm.contains(Meeting)) {

			System.out.println("Creation of meeting is successful");

		}

		else {

			System.out.println("Creation of meeting is not successful");

		}
	}

	@Then("^to close the CRM browser$")
	public void close_the_CRMbrowser() throws Throwable {
	    driver.close();
	}
}
