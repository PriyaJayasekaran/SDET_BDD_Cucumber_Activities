package stepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class CountingDashlets {
	WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Login to AlchemyCRM$")
    public void login_to_AlchemyCRM() throws Throwable {
    	driver = new FirefoxDriver();	
		wait = new WebDriverWait(driver, 10);
		
		driver.get("http://alchemy.hguy.co/crm");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.findElement(By.id("user_name")).sendKeys("admin");
		driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
		driver.findElement(By.xpath("//input[@name='Login']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    @Given("^count the number of Dashlets on Hompepage$")
    public void count_the_number_of_Dashlets_on_Hompepage() throws Throwable {
    	 //List<WebElement> dashlet = driver.findElements(By.xpath("//a"));
    	 //System.out.println("Count : " +dashlet.size());
   	
    	List<WebElement> count = driver.findElements(By.className("dashlet-title"));
      	 System.out.println("Count of Dashlets on HomePage : " +count.size()); 
      	 
      	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    @Then("^print the number of dashlets into console$")
    public void print_the_number_of_dashlets_into_console() throws Throwable {
    	 	 
   	List<WebElement> listElement = driver.findElements(By.className("dashlet-title"));
   	for(int i =0;i<listElement.size();i++) {
   	 String elementText = listElement.get(i).getText(); 
   	 System.out.println("Printing the title of Dashlets: " +elementText); 
   	 
   	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
   	}
    }
    

    @Then("^Logout from Alchemy CRM$")
    public void logout_from_Alchemy_CRM() throws Throwable {
        driver.close();
    } 
}
